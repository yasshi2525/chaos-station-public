function _get() { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get.bind(); } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return _get.apply(this, arguments); }
function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }
function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }
function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }
          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }
        return n[i].exports;
      }
      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
      return o;
    }
    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      // 通常このファイルを編集する必要はありません。ゲームの処理は main.js に記述してください
      var main_1 = require("./main");
      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        });
        // セッションパラメーター
        param.sessionParameter = {};
        // コンテンツが動作している環境がゲームアツマール上かどうか
        param.isAtsumaru = typeof window !== 'undefined' && typeof window.RPGAtsumaru !== 'undefined';
        // 乱数生成器
        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
        var scene = new g.Scene({
          game: g.game,
          name: '_bootstrap'
        });
        // セッションパラメーターを受け取ってゲームを開始します
        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === 'start' && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }
            g.game.popScene();
            (0, main_1.main)(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++;
            // 待ち時間を超えた場合はゲームを開始します
            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              (0, main_1.main)(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 11
    }],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.BehaviorManager = void 0;
      var BehaviorManager = /*#__PURE__*/_createClass(function BehaviorManager(opts) {
        _classCallCheck(this, BehaviorManager);
        this.scene = opts.scene;
        this.resourceManager = opts.resourceManager;
        this.projectionManager = opts.projectionManager;
        this.targetLayer = this.projectionManager.getTargetLayer();
      });
      exports.BehaviorManager = BehaviorManager;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.DemoManager = void 0;
      var projection_manager_1 = require("./projection_manager");
      var thin_panel_view_1 = require("../views/thin_panel_view");
      var DemoManager = /*#__PURE__*/function () {
        function DemoManager(opts) {
          _classCallCheck(this, DemoManager);
          this.scene = opts.scene;
          this.resourceManager = opts.resourceManager;
          this.grid = opts.grid;
        }
        _createClass(DemoManager, [{
          key: "start",
          value: function start() {
            var _this = this;
            var projectionManager;
            if (this.grid) {
              var targetLayer = new g.E({
                scene: this.scene,
                parent: this.scene,
                width: 500,
                height: 500,
                x: g.game.width - 500
              });
              // eslint-disable-next-line prefer-const
              projectionManager = new projection_manager_1.ProjectionManager({
                scene: this.scene,
                angle: this.resourceManager.angle,
                targetLayer: targetLayer,
                logical: {
                  logicalX: 1,
                  logicalY: 1,
                  logicalZ: 1
                }
              });
              var size = 50;
              for (var y = 0; y < 10; y++) {
                for (var x = 0; x < 10; x++) {
                  projectionManager.add(new thin_panel_view_1.ThinPanelView({
                    scene: this.scene,
                    projectionManager: projectionManager,
                    logicalX: x / 10,
                    logicalY: y / 10,
                    logicalZ: 0,
                    size: size - 4,
                    type: 'x'
                  }));
                }
              }
            }
            var minAngle = 0;
            var maxAngle = Math.PI * 0.4;
            var velocity = 1 / g.game.fps / (2 * Math.PI);
            this.scene.onUpdate.add(function () {
              _this.resourceManager.angle += velocity;
              if (projectionManager) {
                projectionManager.angle += velocity;
              }
              if (velocity > 0 && _this.resourceManager.angle > maxAngle || velocity < 0 && _this.resourceManager.angle < minAngle) {
                velocity = -velocity;
              }
            });
          }
        }]);
        return DemoManager;
      }();
      exports.DemoManager = DemoManager;
    }, {
      "../views/thin_panel_view": 18,
      "./projection_manager": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ProjectionManager = void 0;
      var ProjectionManager = /*#__PURE__*/function () {
        function ProjectionManager(opts) {
          var _this2 = this;
          _classCallCheck(this, ProjectionManager);
          this.scene = opts.scene;
          this.targetLayer = opts.targetLayer;
          this.logical = opts.logical;
          this._angle = opts.angle;
          this.subjects = [];
          this.onMove = new g.Trigger();
          this.onMove.add(function (v) {
            _this2.subjects.splice(_this2.subjects.indexOf(v), 1);
            _this2.targetLayer.remove(v);
            _this2.insert(v);
          });
        }
        _createClass(ProjectionManager, [{
          key: "add",
          value: function add(view) {
            this.insert(view);
          }
        }, {
          key: "project",
          value: function project(point3D) {
            // 数学的な z軸 とは反対向きが正
            return {
              x: point3D.logicalX / this.logical.logicalX * this.targetLayer.width,
              y: ((point3D.logicalY / this.logical.logicalY - 0.5) * Math.cos(this._angle) - point3D.logicalZ / this.logical.logicalZ * Math.sin(this._angle) + 0.5) * this.targetLayer.height
            };
          }
        }, {
          key: "reflect",
          value: function reflect(view) {
            // z値は0とする
            var y0 = view.y / this.targetLayer.height - 0.5;
            return {
              logicalX: view.x / this.targetLayer.width * this.logical.logicalX,
              logicalY: (y0 * Math.cos(this._angle) + y0 * Math.sin(this._angle) * Math.tan(this._angle)) * this.logical.logicalY + this.logical.logicalY / 2,
              logicalZ: 0
            };
          }
        }, {
          key: "getSubjects",
          value: function getSubjects() {
            return this.subjects;
          }
        }, {
          key: "getTargetLayer",
          value: function getTargetLayer() {
            return this.targetLayer;
          }
        }, {
          key: "angle",
          get: function get() {
            return this._angle;
          },
          set: function set(theta) {
            var _this3 = this;
            this._angle = theta;
            this.subjects.forEach(function (s) {
              return s.onRotated.fire(_this3._angle);
            });
          }
        }, {
          key: "size",
          get: function get() {
            return this.logical;
          }
        }, {
          key: "insert",
          value: function insert(target) {
            var after;
            for (var i = 0; i < this.subjects.length; i++) {
              if (target.logicalOffset.logicalY < this.subjects[i].logicalOffset.logicalY) {
                after = this.subjects[i];
                this.subjects.splice(i, 0, target);
                this.targetLayer.insertBefore(target, after);
                return;
              }
            }
            this.subjects.push(target);
            this.targetLayer.append(target);
          }
        }]);
        return ProjectionManager;
      }();
      exports.ProjectionManager = ProjectionManager;
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ResourceManager = void 0;
      var projection_manager_1 = require("./projection_manager");
      var platform_view_1 = require("../views/platform_view");
      var stair_view_1 = require("../views/stair_view");
      var train_behavior_1 = require("./train_behavior");
      var spawn_behavior_1 = require("./spawn_behavior");
      var stair_behavior_1 = require("./stair_behavior");
      var rider_behavior_1 = require("./rider_behavior");
      var ResourceManager = /*#__PURE__*/function () {
        function ResourceManager(opts) {
          _classCallCheck(this, ResourceManager);
          this.scene = opts.scene;
          this._angle = opts.angle;
          var layerOpts = {
            scene: this.scene,
            parent: this.scene,
            x: g.game.width / 2,
            y: g.game.height / 2,
            width: g.game.width / 2,
            height: g.game.height / 4,
            anchorX: 0.5,
            anchorY: 0.5
          };
          this.groundLayer = new g.E(layerOpts);
          this.platformLayer = new g.E(layerOpts);
          this.tooltipLayer = new g.E({
            scene: this.scene,
            parent: this.scene
          });
          this.platforms = [];
          var resourceOpts = {
            scene: this.scene,
            angle: this._angle,
            logical: {
              logicalX: 1,
              logicalY: 1,
              logicalZ: 1
            }
          };
          this.groundResources = new projection_manager_1.ProjectionManager(Object.assign({
            targetLayer: this.groundLayer
          }, resourceOpts));
          this.platformResources = new projection_manager_1.ProjectionManager(Object.assign({
            targetLayer: this.platformLayer
          }, resourceOpts));
          this.behaviors = [];
          var behaviorOpts = {
            scene: this.scene,
            resourceManager: this
          };
          this.trainBehavior = new train_behavior_1.TrainBehavior(behaviorOpts);
          this.behaviors.push(this.trainBehavior);
          this.spawnBehavior = new spawn_behavior_1.SpawnBehavior(behaviorOpts);
          this.behaviors.push(this.spawnBehavior);
          this.stairBehavior = new stair_behavior_1.StairBehavior(behaviorOpts);
          this.behaviors.push(this.stairBehavior);
          this.riderBehavior = new rider_behavior_1.RiderBehavior(behaviorOpts);
          this.behaviors.push(this.riderBehavior);
        }
        _createClass(ResourceManager, [{
          key: "angle",
          get: function get() {
            return this._angle;
          },
          set: function set(v) {
            this.groundResources.angle = v;
            this.platformResources.angle = v;
            this._angle = v;
          }
        }, {
          key: "addResourceOnGround",
          value: function addResourceOnGround(view) {
            this.groundResources.add(view);
          }
        }, {
          key: "addResourceOnPlatform",
          value: function addResourceOnPlatform(view) {
            this.platformResources.add(view);
          }
        }, {
          key: "addPlatform",
          value: function addPlatform(view) {
            this.platforms.push(view);
            this.riderBehavior.addPlatform(view);
            this.trainBehavior.addPlatform(view);
            this.addResourceOnGround(view);
          }
        }, {
          key: "addStair",
          value: function addStair(view, on) {
            this.spawnBehavior.add(view);
            this.stairBehavior.add(view, on);
            this.riderBehavior.addStair(view, on);
            this.addResourceOnPlatform(view);
          }
        }, {
          key: "addTrain",
          value: function addTrain(view, destination) {
            this.addResourceOnGround(view);
          }
        }, {
          key: "addPassenger",
          value: function addPassenger(view) {
            this.addResourceOnPlatform(view);
          }
        }, {
          key: "getGroundResources",
          value: function getGroundResources() {
            return this.groundResources;
          }
        }, {
          key: "getPlatformResources",
          value: function getPlatformResources() {
            return this.platformResources;
          }
        }, {
          key: "getTrainBehavior",
          value: function getTrainBehavior() {
            return this.trainBehavior;
          }
        }, {
          key: "getSpawnBehavior",
          value: function getSpawnBehavior() {
            return this.spawnBehavior;
          }
        }, {
          key: "getStairBehavior",
          value: function getStairBehavior() {
            return this.stairBehavior;
          }
        }, {
          key: "getRiderBehavior",
          value: function getRiderBehavior() {
            return this.riderBehavior;
          }
        }, {
          key: "getTooltipLayer",
          value: function getTooltipLayer() {
            return this.tooltipLayer;
          }
        }, {
          key: "start",
          value: function start() {
            this.behaviors.forEach(function (b) {
              return b.start();
            });
            var platform = new platform_view_1.PlatformView({
              scene: this.scene,
              baseWidth: this.groundLayer.width,
              baseHeight: this.groundLayer.height,
              projectionManager: this.groundResources,
              logicalX: 0.5,
              logicalY: 0.5,
              logicalZ: 0
            });
            this.addPlatform(platform);
            this.addStair(new stair_view_1.StairView({
              scene: this.scene,
              projectionManager: this.platformResources,
              logicalX: 0.75,
              logicalY: 0.35,
              logicalZ: 0
            }), platform);
          }
        }, {
          key: "findPlatformOn",
          value: function findPlatformOn(loc) {
            return this.platforms.find(function (p) {
              return p.contains(loc);
            });
          }
        }]);
        return ResourceManager;
      }();
      exports.ResourceManager = ResourceManager;
    }, {
      "../views/platform_view": 16,
      "../views/stair_view": 17,
      "./projection_manager": 4,
      "./rider_behavior": 6,
      "./spawn_behavior": 7,
      "./stair_behavior": 8,
      "./train_behavior": 10
    }],
    6: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.RiderBehavior = void 0;
      var behavior_manager_1 = require("./behavior_manager");
      var passenger_view_1 = require("../views/passenger_view");
      var queuePenalty = 0.01;
      var queueDistance = 2;
      var RiderBehavior = /*#__PURE__*/function (_behavior_manager_1$B) {
        _inherits(RiderBehavior, _behavior_manager_1$B);
        var _super = _createSuper(RiderBehavior);
        function RiderBehavior(opts) {
          var _this4;
          _classCallCheck(this, RiderBehavior);
          _this4 = _super.call(this, Object.assign(Object.assign({}, opts), {
            projectionManager: opts.resourceManager.getPlatformResources()
          }));
          _this4.stairs = [];
          _this4.walkers = [];
          _this4.queues = [];
          return _this4;
        }
        _createClass(RiderBehavior, [{
          key: "addPlatform",
          value: function addPlatform(view) {
            this.stairs.push({
              stairs: [],
              on: view
            });
            this.walkers.push({
              list: [],
              on: view
            });
            var queues = [];
            var xLen = view.getBaseWidth() / passenger_view_1.PassengerView.baseWidth;
            for (var x = 0; x < xLen; x++) {
              var offset = {
                logicalX: x / xLen * this.projectionManager.size.logicalX,
                logicalY: view.logicalOffset.logicalY + view.logicalSize.logicalY / 2 - 0.002,
                logicalZ: 0
              };
              queues.push({
                enabled: true,
                offset: offset,
                queue: []
              });
            }
            this.queues.push({
              queues: queues,
              on: view
            });
          }
        }, {
          key: "addStair",
          value: function addStair(view, on) {
            this.stairs.find(function (s) {
              return s.on === on;
            }).stairs.push(view);
            this.queues.find(function (q) {
              return q.on === on;
            }).queues.filter(function (q) {
              return view.contains(q.offset);
            }).forEach(function (q) {
              q.enabled = false;
            });
          }
        }, {
          key: "notifyEnter",
          value: function notifyEnter(view, on, base) {
            this.walkers.find(function (w) {
              return w.on === base;
            }).list.push(view);
          }
        }, {
          key: "start",
          value: function start() {
            var _this5 = this;
            this.scene.onUpdate.add(function () {
              _this5.walkers.forEach(function (_ref) {
                var list = _ref.list,
                  on = _ref.on;
                list.forEach(function (subject) {
                  var goal = _this5.findGoal(subject, _this5.queues.find(function (q) {
                    return q.on === on;
                  }).queues);
                  // 目的地に近いなら、列に並ぶ
                  if (g.Util.distanceBetweenOffsets({
                    x: subject.logicalOffset.logicalX,
                    y: subject.logicalOffset.logicalY
                  }, {
                    x: goal.offset.logicalX,
                    y: goal.offset.logicalY
                  }) < passenger_view_1.PassengerView.baseWidth / _this5.targetLayer.width * _this5.projectionManager.size.logicalX) {
                    list.splice(list.indexOf(subject), 1);
                    goal.queue.push(subject);
                    return;
                  }
                  // 列が出来ているなら、列に並ぼうとする
                  if (goal.queue.length > 0) {
                    var nearest = _this5.findNearestQueue(subject, goal);
                    if (g.Util.distanceBetweenOffsets({
                      x: subject.logicalOffset.logicalX,
                      y: subject.logicalOffset.logicalY
                    }, {
                      x: nearest.logicalOffset.logicalX,
                      y: nearest.logicalOffset.logicalY
                    }) < passenger_view_1.PassengerView.baseWidth / _this5.targetLayer.width * _this5.projectionManager.size.logicalX * queueDistance) {
                      list.splice(list.indexOf(subject), 1);
                      goal.queue.push(subject);
                    } else {
                      _this5.walk(subject, nearest.logicalOffset);
                    }
                    return;
                  }
                  // 列が出来ていないなら、目的地を目指そうとする
                  _this5.walk(subject, goal.offset);
                });
              });
            });
          }
        }, {
          key: "findGoal",
          value: function findGoal(subject, goals) {
            return goals.filter(function (g) {
              return g.enabled;
            }).reduce(function (prev, current) {
              var prevDist = g.Util.distanceBetweenOffsets({
                x: subject.logicalOffset.logicalX,
                y: subject.logicalOffset.logicalY
              }, {
                x: prev.offset.logicalX,
                y: prev.offset.logicalY
              });
              var currentDist = g.Util.distanceBetweenOffsets({
                x: subject.logicalOffset.logicalX,
                y: subject.logicalOffset.logicalY
              }, {
                x: current.offset.logicalX,
                y: current.offset.logicalY
              });
              return prevDist + prev.queue.length * queuePenalty < currentDist + current.queue.length * queuePenalty ? prev : current;
            });
          }
        }, {
          key: "findNearestQueue",
          value: function findNearestQueue(subject, goal) {
            return goal.queue.reduce(function (prev, current) {
              var prevDist = g.Util.distanceBetweenOffsets({
                x: subject.logicalOffset.logicalX,
                y: subject.logicalOffset.logicalY
              }, {
                x: prev.logicalOffset.logicalX,
                y: prev.logicalOffset.logicalY
              });
              var currentDist = g.Util.distanceBetweenOffsets({
                x: subject.logicalOffset.logicalX,
                y: subject.logicalOffset.logicalY
              }, {
                x: current.logicalOffset.logicalX,
                y: current.logicalOffset.logicalY
              });
              return prevDist < currentDist ? prev : current;
            });
          }
        }, {
          key: "walk",
          value: function walk(subject, destination) {
            var theta = Math.atan2(destination.logicalY - subject.logicalOffset.logicalY, destination.logicalX - subject.logicalOffset.logicalX);
            subject.logicalOffset = {
              logicalX: subject.logicalOffset.logicalX + 0.01 * Math.cos(theta),
              logicalY: subject.logicalOffset.logicalY + 0.01 * Math.sin(theta),
              logicalZ: 0
            };
          }
        }]);
        return RiderBehavior;
      }(behavior_manager_1.BehaviorManager);
      exports.RiderBehavior = RiderBehavior;
    }, {
      "../views/passenger_view": 15,
      "./behavior_manager": 2
    }],
    7: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.SpawnBehavior = void 0;
      var behavior_manager_1 = require("./behavior_manager");
      var passenger_view_1 = require("../views/passenger_view");
      var interval = 500;
      var SpawnBehavior = /*#__PURE__*/function (_behavior_manager_1$B2) {
        _inherits(SpawnBehavior, _behavior_manager_1$B2);
        var _super2 = _createSuper(SpawnBehavior);
        function SpawnBehavior(opts) {
          var _this6;
          _classCallCheck(this, SpawnBehavior);
          _this6 = _super2.call(this, Object.assign(Object.assign({}, opts), {
            projectionManager: opts.resourceManager.getPlatformResources()
          }));
          _this6.spawners = [];
          return _this6;
        }
        _createClass(SpawnBehavior, [{
          key: "add",
          value: function add(view) {
            this.spawners.push(view);
          }
        }, {
          key: "start",
          value: function start() {
            var _this7 = this;
            this.scene.setInterval(function () {
              var on = _this7.spawners[Math.floor(g.game.random.generate() * _this7.spawners.length)];
              var logicalX = on.logicalOffset.logicalX + on.logicalSize.logicalX * (g.game.random.generate() - 0.5);
              var logicalY = on.logicalOffset.logicalY + (g.game.random.generate() - 0.5) * on.logicalSize.logicalY;
              var logicalZ = on.getLogicalZat(logicalX);
              var subject = new passenger_view_1.PassengerView({
                scene: _this7.scene,
                projectionManager: _this7.projectionManager,
                logicalX: logicalX,
                logicalY: logicalY,
                logicalZ: logicalZ
              });
              _this7.resourceManager.addPassenger(subject);
              _this7.resourceManager.getStairBehavior().notifySpawn(subject, on);
            }, interval);
          }
        }]);
        return SpawnBehavior;
      }(behavior_manager_1.BehaviorManager);
      exports.SpawnBehavior = SpawnBehavior;
    }, {
      "../views/passenger_view": 15,
      "./behavior_manager": 2
    }],
    8: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.StairBehavior = void 0;
      var behavior_manager_1 = require("./behavior_manager");
      var speed = 0.001;
      var StairBehavior = /*#__PURE__*/function (_behavior_manager_1$B3) {
        _inherits(StairBehavior, _behavior_manager_1$B3);
        var _super3 = _createSuper(StairBehavior);
        function StairBehavior(opts) {
          var _this8;
          _classCallCheck(this, StairBehavior);
          _this8 = _super3.call(this, Object.assign(Object.assign({}, opts), {
            projectionManager: opts.resourceManager.getPlatformResources()
          }));
          _this8.stairs = [];
          _this8.mapper = [];
          return _this8;
        }
        _createClass(StairBehavior, [{
          key: "add",
          value: function add(view, on) {
            this.stairs.push({
              stair: view,
              on: on
            });
            this.mapper.push({
              stair: view,
              subjects: []
            });
          }
        }, {
          key: "start",
          value: function start() {
            var _this9 = this;
            this.scene.onUpdate.add(function () {
              _this9.stairs.forEach(function (_ref2) {
                var stair = _ref2.stair,
                  on = _ref2.on;
                var subjects = _this9.mapper.find(function (m) {
                  return m.stair === stair;
                }).subjects;
                subjects.forEach(function (s) {
                  s.logicalOffset = {
                    logicalX: s.logicalOffset.logicalX - speed,
                    logicalY: s.logicalOffset.logicalY,
                    logicalZ: stair.getLogicalZat(s.logicalOffset.logicalX - speed)
                  };
                });
                subjects.filter(function (s) {
                  return !stair.contains(s.logicalOffset);
                }).forEach(function (s) {
                  subjects.splice(subjects.indexOf(s), 1);
                  _this9.resourceManager.getRiderBehavior().notifyEnter(s, stair, on);
                });
              });
            });
          }
        }, {
          key: "notifySpawn",
          value: function notifySpawn(subject, on) {
            this.mapper.find(function (_ref3) {
              var stair = _ref3.stair;
              return stair === on;
            }).subjects.push(subject);
          }
        }]);
        return StairBehavior;
      }(behavior_manager_1.BehaviorManager);
      exports.StairBehavior = StairBehavior;
    }, {
      "./behavior_manager": 2
    }],
    9: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TooltipManager = void 0;
      var TooltipManager = /*#__PURE__*/function () {
        function TooltipManager(opts) {
          var _this10 = this;
          _classCallCheck(this, TooltipManager);
          this.scene = opts.scene;
          this.targetLayer = opts.targetLayer;
          this.tooltips = [];
          this.onStart = new g.Trigger();
          this.onEnd = new g.Trigger();
          this.onStart.add(function (v) {
            return _this10.disableOther(v);
          });
          this.onEnd.add(function (v) {
            return _this10.enableOther(v);
          });
        }
        _createClass(TooltipManager, [{
          key: "add",
          value: function add(view) {
            this.targetLayer.append(view);
            this.tooltips.push(view);
          }
        }, {
          key: "disableOther",
          value: function disableOther(subject) {
            this.tooltips.filter(function (v) {
              return v !== subject;
            }).forEach(function (v) {
              return v.disable();
            });
          }
        }, {
          key: "enableOther",
          value: function enableOther(subject) {
            this.tooltips.filter(function (v) {
              return v !== subject;
            }).forEach(function (v) {
              return v.enable();
            });
          }
        }]);
        return TooltipManager;
      }();
      exports.TooltipManager = TooltipManager;
    }, {}],
    10: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TrainBehavior = void 0;
      var train_view_1 = require("../views/train_view");
      var behavior_manager_1 = require("./behavior_manager");
      var TrainBehavior = /*#__PURE__*/function (_behavior_manager_1$B4) {
        _inherits(TrainBehavior, _behavior_manager_1$B4);
        var _super4 = _createSuper(TrainBehavior);
        function TrainBehavior(opts) {
          var _this11;
          _classCallCheck(this, TrainBehavior);
          _this11 = _super4.call(this, Object.assign(Object.assign({}, opts), {
            projectionManager: opts.resourceManager.getGroundResources()
          }));
          _this11.trains = [];
          return _this11;
        }
        _createClass(TrainBehavior, [{
          key: "addPlatform",
          value: function addPlatform(view) {
            var train = new train_view_1.TrainView({
              scene: this.scene,
              projectionManager: this.projectionManager,
              baseWidth: 400,
              baseHeight: 100,
              doors: 2,
              logicalX: this.projectionManager.size.logicalX * 2,
              logicalY: view.logicalOffset.logicalY + view.logicalSize.logicalY / 2 + 100 / this.projectionManager.getTargetLayer().height * this.projectionManager.size.logicalY / 2,
              logicalZ: 0,
              destination: view.logicalOffset
            });
            this.trains.push({
              destination: view,
              list: [train]
            });
            this.resourceManager.addTrain(train, view);
            train.start();
          }
        }, {
          key: "start",
          value: function start() {}
        }]);
        return TrainBehavior;
      }(behavior_manager_1.BehaviorManager);
      exports.TrainBehavior = TrainBehavior;
    }, {
      "../views/train_view": 20,
      "./behavior_manager": 2
    }],
    11: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;
      var game_scene_1 = require("./scenes/game_scene");
      function main(param) {
        var _a;
        g.game.random = param.random;
        g.game.vars.originalParameter = param;
        g.game.pushScene(new game_scene_1.GameScene({
          game: g.game,
          debug: (_a = param.sessionParameter.debug) !== null && _a !== void 0 ? _a : {
            grid: false,
            rotate: false
          }
        }));
      }
      exports.main = main;
    }, {
      "./scenes/game_scene": 12
    }],
    12: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.GameScene = void 0;
      var resource_manager_1 = require("../behaviors/resource_manager");
      var tooltip_manager_1 = require("../behaviors/tooltip_manager");
      var tooltip_stair_view_1 = require("../views/tooltip_stair_view");
      var demo_manager_1 = require("../behaviors/demo_manager");
      var GameScene = /*#__PURE__*/function (_g$Scene) {
        _inherits(GameScene, _g$Scene);
        var _super5 = _createSuper(GameScene);
        function GameScene(opts) {
          var _this12;
          _classCallCheck(this, GameScene);
          _this12 = _super5.call(this, Object.assign(Object.assign({}, opts), {
            name: 'game'
          }));
          _this12.onLoad.add(function () {
            var resourceManager = new resource_manager_1.ResourceManager({
              scene: _assertThisInitialized(_this12),
              angle: Math.PI / 4
            });
            var demoManager;
            if (opts.debug.rotate) {
              // eslint-disable-next-line prefer-const
              demoManager = new demo_manager_1.DemoManager({
                scene: _assertThisInitialized(_this12),
                resourceManager: resourceManager,
                grid: opts.debug.grid
              });
            }
            var tooltipManager = new tooltip_manager_1.TooltipManager({
              scene: _assertThisInitialized(_this12),
              targetLayer: resourceManager.getTooltipLayer()
            });
            tooltipManager.add(new tooltip_stair_view_1.TooltipStairView({
              scene: _assertThisInitialized(_this12),
              resourceManager: resourceManager,
              tooltipManager: tooltipManager,
              x: 200,
              y: 200
            }));
            demoManager === null || demoManager === void 0 ? void 0 : demoManager.start();
            resourceManager.start();
          });
          return _this12;
        }
        return _createClass(GameScene);
      }(g.Scene);
      exports.GameScene = GameScene;
    }, {
      "../behaviors/demo_manager": 3,
      "../behaviors/resource_manager": 5,
      "../behaviors/tooltip_manager": 9,
      "../views/tooltip_stair_view": 19
    }],
    13: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ThreeDimensionalView = void 0;
      var ThreeDimensionalView = /*#__PURE__*/function (_g$E) {
        _inherits(ThreeDimensionalView, _g$E);
        var _super6 = _createSuper(ThreeDimensionalView);
        function ThreeDimensionalView(opts) {
          var _this13;
          _classCallCheck(this, ThreeDimensionalView);
          _this13 = _super6.call(this, Object.assign(Object.assign({}, opts), opts.projectionManager.project(opts)));
          _this13.onRotated = new g.Trigger();
          _this13.logical = {
            logicalX: opts.logicalX,
            logicalY: opts.logicalY,
            logicalZ: opts.logicalZ
          };
          _this13.baseWidth = opts.baseWidth;
          _this13.baseHeight = opts.baseHeight;
          _this13.projectionManager = opts.projectionManager;
          _this13.onRotated.add(function () {
            var _this13$projectionMan = _this13.projectionManager.project(_this13.logical),
              x = _this13$projectionMan.x,
              y = _this13$projectionMan.y;
            _this13.x = x;
            _this13.y = y;
            _this13.modified();
            _this13.projectionManager.onMove.fire(_assertThisInitialized(_this13));
          });
          return _this13;
        }
        _createClass(ThreeDimensionalView, [{
          key: "logicalOffset",
          get: function get() {
            return this.logical;
          },
          set: function set(v) {
            this.logical.logicalX = v.logicalX;
            this.logical.logicalY = v.logicalY;
            this.logical.logicalZ = v.logicalZ;
            var _this$projectionManag = this.projectionManager.project(this.logical),
              x = _this$projectionManag.x,
              y = _this$projectionManag.y;
            this.x = x;
            this.y = y;
            this.modified();
            this.projectionManager.onMove.fire(this);
          }
        }, {
          key: "logicalSize",
          get: function get() {
            return {
              logicalX: this.baseWidth / this.projectionManager.getTargetLayer().width * this.projectionManager.size.logicalX,
              logicalY: this.baseHeight / this.projectionManager.getTargetLayer().height * this.projectionManager.size.logicalY,
              logicalZ: 0
            };
          }
        }, {
          key: "contains",
          value: function contains(target) {
            return this.logicalOffset.logicalX - this.logicalSize.logicalX / 2 < target.logicalX && target.logicalX < this.logicalOffset.logicalX + this.logicalSize.logicalX / 2 && this.logicalOffset.logicalY - this.logicalSize.logicalY / 2 < target.logicalY && target.logicalY < this.logicalOffset.logicalY + this.logicalSize.logicalY / 2;
          }
        }]);
        return ThreeDimensionalView;
      }(g.E);
      exports.ThreeDimensionalView = ThreeDimensionalView;
    }, {}],
    14: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.DeployableView = void 0;
      var width = 125;
      var height = 75;
      var disabledAlpha = 0.5;
      var defAlpha = 0.75;
      var pressedAlpha = 1.0;
      var subjectDefAlpha = 0.1;
      var subjectAlpha = 0.5;
      var DeployableView = /*#__PURE__*/function (_g$E2) {
        _inherits(DeployableView, _g$E2);
        var _super7 = _createSuper(DeployableView);
        function DeployableView(opts) {
          var _this14;
          _classCallCheck(this, DeployableView);
          _this14 = _super7.call(this, Object.assign(Object.assign({}, opts), {
            anchorX: 0.5,
            anchorY: 0.5,
            width: width,
            height: height
          }));
          _this14.tooltipManager = opts.tooltipManager;
          _this14.resourceManager = opts.resourceManager;
          _this14._source = new g.FilledRect({
            scene: _this14.scene,
            parent: _assertThisInitialized(_this14),
            width: width,
            height: height,
            opacity: defAlpha,
            cssColor: opts.src
          });
          _this14._subject = new g.FilledRect({
            scene: _this14.scene,
            parent: _assertThisInitialized(_this14),
            width: width,
            height: height,
            opacity: subjectDefAlpha,
            cssColor: opts.src,
            touchable: true
          });
          var pid;
          _this14._subject.onPointDown.add(function (e) {
            if (pid === undefined) {
              pid = e.pointerId;
              _this14._source.opacity = pressedAlpha;
              _this14._source.modified();
              _this14._subject.opacity = subjectAlpha;
              _this14._subject.modified();
              _this14.tooltipManager.onStart.fire(_assertThisInitialized(_this14));
            }
          });
          _this14._subject.onPointMove.add(function (e) {
            if (pid === e.pointerId) {
              _this14._subject.x += e.prevDelta.x;
              _this14._subject.y += e.prevDelta.y;
              _this14._subject.modified();
            }
          });
          _this14._subject.onPointUp.add(function (e) {
            if (pid === e.pointerId) {
              var ev = _this14.resourceManager.getPlatformResources().getTargetLayer().globalToLocal(_this14._subject.localToGlobal({
                x: _this14._subject.width / 2,
                y: _this14._subject.height / 2
              }));
              _this14._subject.moveTo({
                x: 0,
                y: 0
              });
              _this14.handleEvent(ev);
              _this14._source.opacity = defAlpha;
              _this14._source.modified();
              _this14._subject.opacity = subjectDefAlpha;
              _this14._subject.modified();
              _this14.tooltipManager.onEnd.fire(_assertThisInitialized(_this14));
              pid = undefined;
            }
          });
          return _this14;
        }
        _createClass(DeployableView, [{
          key: "disable",
          value: function disable() {
            this._source.opacity = disabledAlpha;
            this._source.modified();
            this._subject.touchable = false;
          }
        }, {
          key: "enable",
          value: function enable() {
            this._source.opacity = defAlpha;
            this._source.modified();
            this._subject.touchable = true;
          }
        }, {
          key: "source",
          get: function get() {
            return this._source;
          }
        }, {
          key: "subject",
          get: function get() {
            return this._subject;
          }
        }]);
        return DeployableView;
      }(g.E);
      exports.DeployableView = DeployableView;
    }, {}],
    15: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.PassengerView = void 0;
      var _3d_view_1 = require("./3d_view");
      var baseWidth = 20;
      var baseHeight = 40;
      var PassengerView = /*#__PURE__*/function (_d_view_1$ThreeDimen) {
        _inherits(PassengerView, _d_view_1$ThreeDimen);
        var _super8 = _createSuper(PassengerView);
        function PassengerView(opts) {
          var _this15;
          _classCallCheck(this, PassengerView);
          _this15 = _super8.call(this, Object.assign(Object.assign({}, opts), {
            baseWidth: baseWidth,
            baseHeight: baseHeight
          }));
          _this15.icon = new g.FilledRect({
            scene: _this15.scene,
            parent: _assertThisInitialized(_this15),
            anchorX: 0.5,
            anchorY: 1,
            width: _this15.baseWidth,
            height: _this15.baseHeight * Math.sin(_this15.projectionManager.angle),
            cssColor: '#000000'
          });
          _this15.icon.append(new g.FilledRect({
            scene: _this15.scene,
            x: 1,
            y: 1,
            width: _this15.baseWidth - 2,
            height: _this15.baseHeight * Math.sin(opts.projectionManager.angle) - 2,
            cssColor: '#6495ed'
          }));
          _this15.onRotated.add(function (angle) {
            _this15.icon.height = Math.sin(angle) * _this15.baseHeight;
            _this15.icon.children[0].height = Math.sin(angle) * _this15.baseHeight;
            _this15.icon.children[0].modified();
            _this15.icon.modified();
          });
          return _this15;
        }
        return _createClass(PassengerView);
      }(_3d_view_1.ThreeDimensionalView);
      PassengerView.baseWidth = baseWidth;
      exports.PassengerView = PassengerView;
    }, {
      "./3d_view": 13
    }],
    16: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.PlatformView = void 0;
      var _3d_view_1 = require("./3d_view");
      var PlatformView = /*#__PURE__*/function (_d_view_1$ThreeDimen2) {
        _inherits(PlatformView, _d_view_1$ThreeDimen2);
        var _super9 = _createSuper(PlatformView);
        function PlatformView(opts) {
          var _this16;
          _classCallCheck(this, PlatformView);
          _this16 = _super9.call(this, opts);
          _this16.icon = new g.FilledRect({
            scene: _this16.scene,
            parent: _assertThisInitialized(_this16),
            anchorX: 0.5,
            anchorY: 0.5,
            width: _this16.baseWidth,
            height: Math.cos(opts.projectionManager.angle) * _this16.baseHeight,
            cssColor: '#778899'
          });
          _this16.onRotated.add(function (angle) {
            _this16.icon.height = Math.cos(angle) * _this16.baseHeight;
            _this16.icon.modified();
          });
          return _this16;
        }
        _createClass(PlatformView, [{
          key: "getBaseWidth",
          value: function getBaseWidth() {
            return this.baseWidth;
          }
        }]);
        return PlatformView;
      }(_3d_view_1.ThreeDimensionalView);
      exports.PlatformView = PlatformView;
    }, {
      "./3d_view": 13
    }],
    17: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.StairView = void 0;
      var _3d_view_1 = require("./3d_view");
      var baseWidth = 150;
      var baseHeight = 100;
      var logicalLength = 0.25; // 高さ
      var StairView = /*#__PURE__*/function (_d_view_1$ThreeDimen3) {
        _inherits(StairView, _d_view_1$ThreeDimen3);
        var _super10 = _createSuper(StairView);
        function StairView(opts) {
          var _this17;
          _classCallCheck(this, StairView);
          _this17 = _super10.call(this, Object.assign(Object.assign({}, opts), {
            baseWidth: baseWidth,
            baseHeight: baseHeight
          }));
          _this17.icon = new g.FilledRect({
            scene: _this17.scene,
            parent: _assertThisInitialized(_this17),
            anchorX: 0.5,
            anchorY: 0.5,
            width: _this17.baseWidth,
            height: _this17.baseHeight * Math.cos(_this17.projectionManager.angle),
            cssColor: '#000000',
            opacity: 0.5
          });
          _this17.icon.append(new g.FilledRect({
            scene: _this17.scene,
            x: 1,
            y: 1,
            width: _this17.baseWidth - 2,
            height: _this17.baseHeight * Math.cos(_this17.projectionManager.angle) - 2,
            cssColor: '#8b0000',
            opacity: 0.5
          }));
          _this17.onRotated.add(function (angle) {
            _this17.icon.height = Math.cos(angle) * _this17.baseHeight;
            _this17.icon.children[0].height = Math.cos(angle) * _this17.baseHeight - 2;
            _this17.icon.modified();
          });
          return _this17;
        }
        _createClass(StairView, [{
          key: "getLogicalZat",
          value: function getLogicalZat(logicalX) {
            return (logicalX - (this.logicalOffset.logicalX - this.logicalSize.logicalX / 2)) / this.logicalSize.logicalX * this.logicalSize.logicalZ;
          }
        }, {
          key: "logicalSize",
          get: function get() {
            return Object.assign(Object.assign({}, _get(_getPrototypeOf(StairView.prototype), "logicalSize", this)), {
              logicalZ: logicalLength
            });
          }
        }]);
        return StairView;
      }(_3d_view_1.ThreeDimensionalView);
      exports.StairView = StairView;
    }, {
      "./3d_view": 13
    }],
    18: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ThinPanelView = void 0;
      var _3d_view_1 = require("./3d_view");
      var ThinPanelView = /*#__PURE__*/function (_d_view_1$ThreeDimen4) {
        _inherits(ThinPanelView, _d_view_1$ThreeDimen4);
        var _super11 = _createSuper(ThinPanelView);
        function ThinPanelView(opts) {
          var _this18;
          _classCallCheck(this, ThinPanelView);
          _this18 = _super11.call(this, Object.assign(Object.assign({}, opts), {
            baseWidth: opts.size,
            baseHeight: opts.size
          }));
          _this18.icon = new g.FilledRect({
            scene: _this18.scene,
            parent: _assertThisInitialized(_this18),
            anchorX: 0.5,
            anchorY: 0.5,
            width: _this18.baseWidth,
            height: _this18.baseHeight,
            cssColor: '#98fb98',
            opacity: 0.25
          });
          _this18.onRotated.add(function (angle) {
            _this18.icon.height = Math.cos(angle) * _this18.baseHeight;
            _this18.icon.opacity = 0.25 * Math.abs(Math.sin(angle)) + 0.25;
            _this18.icon.modified();
          });
          return _this18;
        }
        return _createClass(ThinPanelView);
      }(_3d_view_1.ThreeDimensionalView);
      exports.ThinPanelView = ThinPanelView;
    }, {
      "./3d_view": 13
    }],
    19: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TooltipStairView = void 0;
      var deployable_view_1 = require("./deployable_view");
      var stair_view_1 = require("./stair_view");
      var TooltipStairView = /*#__PURE__*/function (_deployable_view_1$De) {
        _inherits(TooltipStairView, _deployable_view_1$De);
        var _super12 = _createSuper(TooltipStairView);
        function TooltipStairView(opts) {
          _classCallCheck(this, TooltipStairView);
          return _super12.call(this, Object.assign(Object.assign({}, opts), {
            src: '#a0522d'
          }));
        }
        _createClass(TooltipStairView, [{
          key: "handleEvent",
          value: function handleEvent(ev) {
            var projectionManager = this.resourceManager.getPlatformResources();
            var offset = projectionManager.reflect(ev);
            var on = this.resourceManager.findPlatformOn(offset);
            if (on) {
              this.resourceManager.addStair(new stair_view_1.StairView(Object.assign({
                scene: this.scene,
                projectionManager: projectionManager
              }, offset)), on);
            }
          }
        }]);
        return TooltipStairView;
      }(deployable_view_1.DeployableView);
      exports.TooltipStairView = TooltipStairView;
    }, {
      "./deployable_view": 14,
      "./stair_view": 17
    }],
    20: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TrainView = void 0;
      var _3d_view_1 = require("./3d_view");
      var doorWidth = 60;
      var doorHeight = 20;
      var acceleration = 0.0001;
      var initialVelocity = -0.01;
      var distanceForStop = initialVelocity * initialVelocity / (2 * acceleration);
      var TrainView = /*#__PURE__*/function (_d_view_1$ThreeDimen5) {
        _inherits(TrainView, _d_view_1$ThreeDimen5);
        var _super13 = _createSuper(TrainView);
        function TrainView(opts) {
          var _this19;
          _classCallCheck(this, TrainView);
          if (opts.logicalX - opts.destination.logicalX < distanceForStop) {
            opts.logicalX = opts.destination.logicalX + distanceForStop;
          }
          _this19 = _super13.call(this, opts);
          _this19.steps = [];
          _this19.doors = [];
          _this19.destination = opts.destination;
          _this19.velocity = initialVelocity;
          _this19.status = 'stopping';
          _this19.body = new g.FilledRect({
            scene: _this19.scene,
            parent: _assertThisInitialized(_this19),
            anchorX: 0.5,
            anchorY: 0.5,
            width: _this19.baseWidth,
            height: _this19.baseHeight * Math.cos(_this19.projectionManager.angle),
            cssColor: '#3cb371',
            opacity: 0.5
          });
          for (var i = 0; i < opts.doors; i++) {
            var band = _this19.baseWidth / opts.doors;
            var center = (i + 0.5) * band;
            _this19.steps.push(new g.FilledRect({
              scene: _this19.scene,
              parent: _this19.body,
              x: center - doorWidth / 2,
              width: doorWidth,
              height: doorHeight * Math.cos(_this19.projectionManager.angle),
              cssColor: '#008b8b',
              opacity: 0.5
            }));
            _this19.doors.push(new g.FilledRect({
              scene: _this19.scene,
              parent: _this19.body,
              x: center - doorWidth / 2,
              width: doorWidth,
              height: doorHeight * Math.cos(_this19.projectionManager.angle),
              cssColor: '#008b8b',
              opacity: 0.5
            }));
          }
          _this19.onRotated.add(function (angle) {
            _this19.body.height = Math.cos(angle) * _this19.baseHeight;
            _this19.body.children.forEach(function (d) {
              d.height = Math.cos(angle) * doorHeight;
              d.modified();
            });
            _this19.body.modified();
          });
          return _this19;
        }
        _createClass(TrainView, [{
          key: "start",
          value: function start() {
            var _this20 = this;
            this.onUpdate.add(function () {
              switch (_this20.status) {
                case 'stopping':
                  if (_this20.logicalOffset.logicalX - _this20.destination.logicalX < distanceForStop) {
                    _this20.velocity += acceleration;
                    if (_this20.velocity >= 0) {
                      _this20.velocity = 0;
                      _this20.logicalOffset = {
                        logicalX: _this20.destination.logicalX,
                        logicalY: _this20.logicalOffset.logicalY,
                        logicalZ: _this20.logicalOffset.logicalZ
                      };
                      _this20.status = 'opening';
                      break;
                    }
                  }
                  _this20.logicalOffset = {
                    logicalX: _this20.logicalOffset.logicalX + _this20.velocity,
                    logicalY: _this20.logicalOffset.logicalY,
                    logicalZ: _this20.logicalOffset.logicalZ
                  };
                  break;
                case 'opening':
                  _this20.doors.forEach(function (d) {
                    d.width -= 1.5;
                    if (d.width < 0) {
                      d.width = 0;
                      _this20.status = 'stay';
                    }
                    d.modified();
                  });
              }
            });
          }
        }]);
        return TrainView;
      }(_3d_view_1.ThreeDimensionalView);
      exports.TrainView = TrainView;
    }, {
      "./3d_view": 13
    }]
  }, {}, [1])(1);
});